package com.sunofbeaches.himalaya.base;

import android.support.v4.app.FragmentActivity;

/**
 * Created by TrillGates on 2019/1/17.
 * God bless my code!
 */
public class BaseActivity extends FragmentActivity {

}
