# 喜马拉雅FM电台项目

基于喜马拉雅的SDK

open.ximalaya.com

视频教程地址：[视频教程传送门->>](https://study.163.com/course/introduction.htm?courseId=1209331970)

感谢喜马拉雅

学习交流网站：www.sunofbeaches.com

项目截图：

![2019-10-05_225218](https://github.com/TrillGates/XimalayaDemo/blob/master/pics/2019-10-05_225218.png)

.
